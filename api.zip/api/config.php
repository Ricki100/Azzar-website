<?php
/**
 * REAL config — never commit this file.
 * See config.example.php for what each value means and where to find it.
 */
return [
    'BREVO_API_KEY' => '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',
    'BREVO_LIST_ID' => 5,
    'BREVO_QUOTE_LIST_ID' => 6,
];
